import scrapy
from scrapy import cmdline
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule


class RecruitInfoSpider(CrawlSpider):
    name = "recruit_info"
    allowed_domains = ["hngxy.goworkla.cn"]
    start_urls = ["https://hngxy.goworkla.cn/module/position_brief/nid-7208/page-1"]

    rules = (Rule(LinkExtractor(allow=r"/module/position_brief/nid-7208/page-\d{1,3}"),
                  callback="parse_item", follow=True),)

    def parse_item(self, response):
        for info in response.xpath('//div[@class="infoTips"]'):
            item = {}
            item["title"] = info.xpath('.//p[@class="tipName"]/text()').get()
            # 简单数据清洗
            name = info.xpath('.//p[@class="tipPlace"]/text()').get()
            name = name.split('：')[-1]
            item["name_"] = name

            description = info.xpath('.//p[@class="tipTime"]/text()').get()
            description = description.split('：')[-1]  # 简单数据清洗 待做
            item["descrip"] = description
            yield item


if __name__ == "__main__":
    from time import sleep
    from tqdm import tqdm
    import threading
    # import multiprocessing

    # 这里同样的，tqdm就是这个进度条最常用的一个方法
    # 里面存一个可迭代对象
    def fun1():
        for i in tqdm(range(1, 1305)):
            # 模拟你的任务
            sleep(0.0001)
        sleep(0.5)

    print('请稍等……')
    fun1()
    # thread = threading.Thread(target=fun1)  # thread imp-threading
    cmdline.execute("scrapy crawl recruit_info".split())
    # thread2 = threading.Thread(target=fun2)
    # thread.start()
    # thread2.start()





    # process = multiprocessing.Process(target=fun1)  # process imp-multiprocessing
    # process2 = multiprocessing.Process(target=fun2)
    # process.start()
    # process2.start()

