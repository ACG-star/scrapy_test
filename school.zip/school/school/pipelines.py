# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from openpyxl import Workbook
import pymysql


class SchoolPipelineExcel:
    def open_spider(self, spider):
        self.wb = Workbook()  # 实例化
        self.ws = self.wb.active  # 创建工作表和活动工作簿
        self.ws.append(['标题', '企业名称', '浏览人数'])  # 写入表头

    def process_item(self, item, spider):
        line = [item['title'], item['name_'], item['descrip']]
        self.ws.append(line)
        self.wb.save(spider.name + '.xls')
        return item


class SchoolPipelineMySQL:
    def open_spider(self, spider):
        # 读取settings.py中的配置项
        host = spider.settings.get("MYSQLDBHOST", "127.0.0.1")  # ,后为缺省设置，即当不能找到配置项时的值
        port = spider.settings.get("MYSQL_DB_PORT", "3306")
        dbname = spider.settings.get("MYSQL_DB_NAME", "Scrapy_test")
        user = spider.settings.get("MYSQL_DB_USER", "pythonSQL")
        pwd = spider.settings.get("MYSQL_DB_PASSWORD", "123456wz")
        # 创建数据库连接
        self.db_conn = pymysql.connect(host=host, port=port, db=dbname, user=user, password=pwd)
        # 打开游标
        self.db_cur = self.db_conn.cursor()

    def process_item(self, item, spider):
        value = (item["title"], item["name_"], item["descrip"])
        sql = "insert into recruit_info(title,name_,descrip)values(%s,%s,%s)"
        try:
            self.db_cur.execute(sql, value)
            self.db_conn.commit()  # 提交事务，应用操作
        except Exception as err:
            self.db_conn.rollback()  # 事务回滚
            print(f'运行时出错！\n{err}')
        # finally:
        #     self.db_cur.close()  # 关闭游标
        #     self.db_conn.close()  # 关闭连接
        return item

    # def close_spider(self, spider):

